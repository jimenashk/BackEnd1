DROP TABLE IF EXISTS odontologos;
CREATE TABLE odontologos(id INTEGER,
NOMBRE varchar(200),
APELLIDO varchar(200),
MATRICULA varchar(200)
);
