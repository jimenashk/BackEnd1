package com.clinicaDental.paciente2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Paciente2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
